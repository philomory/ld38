class Enemy::Sentry < Enemy::Watcher
  
  def rotate
  end
  
  def range
    10
  end 
  
end

module SafeYAML
  VERSION = "1.0.4"
end

module RbReadline
  RB_READLINE_VERSION = "0.5.3"
end
